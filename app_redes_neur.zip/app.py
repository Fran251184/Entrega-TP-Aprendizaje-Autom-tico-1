import streamlit as st
import joblib
import pandas as pd
import os
from clases_y_funciones import   min_max_var_num, TratamientoDeDatos, NeuralNetworkClassifier, NeuralNetworkRegressor, input_features

# Obtener el directorio del script actual
path_dir=os.path.dirname(os.path.abspath(__file__))

# Se carga el pipeline del modelo de regresión.
pkl_path_reg = os.path.join(path_dir, 'lluvia_australia_reg_prediction.pkl')
pipe_reg = joblib.load(pkl_path_reg)

# Se carga el pipeline del modelo de clasificación.

pkl_path_cla = os.path.join(path_dir, 'lluvia_australia_clas_prediction.pkl')
pipe_cla = joblib.load(pkl_path_cla)



st.markdown("# Predicción de lluvia en Australia")

def get_user_input():
    # Proporcionar un formulario para que el usuario ingrese valores
    input_dict = {}
    for variable in input_features:
        if variable == 'RainToday':
            # Permitir al usuario seleccionar "Sí" o "No" y asignar 1 o 0 respectivamente
            input_value = 1 if st.selectbox(f"Select {variable}", ['No', 'Yes']) == 'Yes' else 0
            input_dict[variable] = input_value	
        elif variable == 'WindDir':
            # Para 'WindDir', permitir al usuario seleccionar de una lista
            wind_direction = st.radio(f"Select Wind Direction for {variable}", ['E', 'N', 'S', 'W'])
            # Asignar 1 a la dirección seleccionada y 0 a las demás
            input_dict['WindDir3pm_N'] = 1 if wind_direction == 'N' else 0
            input_dict['WindDir3pm_S'] = 1 if wind_direction == 'S' else 0
            input_dict['WindDir3pm_W'] = 1 if wind_direction == 'W' else 0
        elif variable == 'Estacion':
            # Para 'Estacion', permitir al usuario seleccionar de una lista
            estacion = st.radio(f"Select Wind Direction for {variable}", ['Otoño', 'Primavera', 'Verano', 'Invierno'])
            # Asignar 1 a la dirección seleccionada y 0 a las demás
            input_dict['Estacion_Otoño'] = 1 if estacion == 'Otoño' else 0
            input_dict['Estacion_Primavera'] = 1 if estacion == 'Primavera' else 0
            input_dict['Estacion_Invierno'] = 1 if estacion == 'Invierno' else 0        
        else:
    # Usar sliders para las variables numéricas
            min_value = min_max_var_num[variable][0]
            max_value = min_max_var_num[variable][1]
            input_value = st.slider(f"Select value for {variable}", min_value=min_value, max_value=max_value, value=min_value, step=0.013)
            input_dict[variable] = input_value
    submit_button = st.button('Submit')
    return pd.DataFrame([input_dict]), submit_button

user_input, submit_button = get_user_input()

# Realizar predicciones 
if submit_button: 
    # Tratamiento de datos
    datos = TratamientoDeDatos(user_input)
    transf_datos = datos.estandarizar_col_num()
    datos_transf_cla = transf_datos 
    # Predicción de regresión
    prediction_reg = pipe_reg.predict(transf_datos)
    prediction_value_reg = prediction_reg.item()
    # Eliminar columnas para la predicción de clasificación
    for i in ['MinTemp', 'MaxTemp', 'Rainfall', 'WindSpeed', 'Temp']:
        dropear= TratamientoDeDatos(datos_transf_cla)
        columna = [i]
        datos_transf_cla = dropear.eliminar_columna(columna)
    # Predicción de clasificación
    prediction_cla = pipe_cla.predict(datos_transf_cla)
    prediction_value_cla = prediction_cla[0]

    # Mostrar la predicción
    st.header("¿Llueve mañana?")
    if prediction_value_cla == 1:
        st.write("<span style='font-size: 24px;'>Sí, llueve: </span>", unsafe_allow_html=True)
        st.write(f"<span style='font-size: 24px;'>{round(prediction_value_reg, 2)} mm</span>", unsafe_allow_html=True, key="prediction_output")
    else:
        st.write("<span style='font-size: 24px;'>No llueve .</span>", unsafe_allow_html=True)
# Enlace a la documentación o más información sobre la aplicación
st.markdown(
    """
    Para conocer más sobre la app:<br>
    [🌧️ App predicción de lluvia en Australia](https://github.com/Fran251184/Entrega-TP-Aprendizaje-Autom-tico-1)
    """, unsafe_allow_html=True
)