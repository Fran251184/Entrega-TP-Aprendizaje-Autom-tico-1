# clases y funciones del pipeline de preprocesamiento.
import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import  StandardScaler

# Lista de características de entrada para el modelo
input_features = ['Humidity', 'Pressure','Cloud','MinTemp','MaxTemp','Rainfall', 'WindSpeed', 'Temp', 
                      'WindDir', 'Estacion', 'RainToday']

# Diccionario que define los rangos para las variables numéricas
min_max_var_num = {'Humidity': (float(0.01),float(100)),'Pressure': (float(100),float(1100)),'Cloud': (float(0.01),float(10)),'MinTemp': (float(-10),float(55)),'MaxTemp': (float(-10),float(55)),'Rainfall': (float(0.01),float(400)),'WindSpeed': (float(0.01),float(200)),'Temp': (float(-10),float(55))}


# Clase para el tratamiento de datos
class TratamientoDeDatos:
    def __init__(self, df):
        """
        Inicializa la clase con un DataFrame.

        :param df: DataFrame a ser utilizado.
        """
        self.df = df

    def estandarizar_col_num(self):
        """
        Estandariza las columnas numéricas del DataFrame.
        """
        columnas_numericas = self.df.select_dtypes(include=['float64']).columns

        self.df[columnas_numericas] = (self.df[columnas_numericas] - self.df[columnas_numericas].mean()) / self.df[columnas_numericas].std()
        return self.df

    def convertir_a_dummies(self, columnas):
        """
        Convierte las columnas especificadas a variables dummy.

        :param columnas: Lista de nombres de columnas a convertir.
        """
        self.df = pd.get_dummies(self.df, columns=columnas, prefix=columnas)

        return self.df

    def eliminar_columna(self, columna):
        """
        Elimina la columnas del DataFrame

        :param columna: Nombre de la columna a eliminar.
        """
        self.df.drop(columna, axis=1, inplace=True)

        return self.df


# Clase para el modelo de clasificación    
class NeuralNetworkClassifier(BaseEstimator, TransformerMixin):
    def __init__(self, input_dim):
        self.input_dim = input_dim
        self.model = self._build_model()

    def _build_model(self):
        model = Sequential()
        model.add(Dense(30, input_shape=(self.input_dim,)))
        model.add(LeakyReLU(alpha=0.01))
        model.add(Dense(128))
        model.add(LeakyReLU(alpha=0.01))
        model.add(Dense(1, activation='sigmoid'))
        model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])
        return model

    def fit(self, X, y):
        self.model.fit(X, y, epochs=3, batch_size=3, verbose=0)
        return self


    def predict(self, X):
        y_pred = self.model.predict(X)
        return (y_pred > 0.5).astype(int)

    def evaluate(self, X, y):
        loss, accuracy = self.model.evaluate(X, y, verbose=0)
        print(f'Pérdida test: {loss}')
        print(f'Exactitud test: {accuracy}')

    def save_model(self, filename):
        self.model.save(filename)

    def load_model(self, filename):
        self.model = load_model(filename)


# Clase para el modelo de regresión
class NeuralNetworkRegressor(BaseEstimator, TransformerMixin):
    def __init__(self, input_dim):
        self.input_dim = input_dim
        self.model = self._build_model()

    def _build_model(self):
        model = Sequential()
        model.add(Dense(30, input_shape=(self.input_dim,)))
        model.add(LeakyReLU(alpha=0.01))
        model.add(Dense(128))
        model.add(LeakyReLU(alpha=0.01))
        model.add(Dense(1, activation='linear'))  # Use 'linear' for regression
        model.compile(optimizer=Adam(), loss='mean_squared_error', metrics=['mae'])
        return model

    def fit(self, X, y):
        self.model.fit(X, y, epochs=3, batch_size=3, verbose=0)
        return self

    def predict(self, X):
        y_pred = self.model.predict(X)
        return np.squeeze(y_pred)  # Ensure the output is a 1D array

    def evaluate(self, X, y):
        y_pred = self.predict(X)
        mae = mean_absolute_error(y, y_pred)
        mse = mean_squared_error(y, y_pred)
        rmse = mean_squared_error(y, y_pred, squared=False)
        r2 = r2_score(y, y_pred)

        print(f'Mean Absolute Error (MAE): {mae}')
        print(f'Mean Squared Error (MSE): {mse}')
        print(f'Root Mean Squared Error (RMSE): {rmse}')
        print(f'R2 Score: {r2}')

    def save_model(self, filename):
        self.model.save(filename)

    def load_model(self, filename):
        self.model = load_model(filename)

