# clases y funciones del pipeline de preprocesamiento.
import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import  StandardScaler

# Lista de características de entrada para el modelo
input_features = ['Humidity', 'Pressure','Cloud','MinTemp','MaxTemp','Rainfall', 'WindSpeed', 'Temp', 
                      'WindDir', 'Estacion', 'RainToday']

# Diccionario que define los rangos para las variables numéricas
min_max_var_num = {'Humidity': (float(0.01),float(100)),'Pressure': (float(100),float(1100)),'Cloud': (float(0.01),float(10)),'MinTemp': (float(-10),float(55)),'MaxTemp': (float(-10),float(55)),'Rainfall': (float(0.01),float(400)),'WindSpeed': (float(0.01),float(200)),'Temp': (float(-10),float(55))}


# Clase para el tratamiento de datos
class TratamientoDeDatos:
    def __init__(self, df):
        """
        Inicializa la clase con un DataFrame.

        :param df: DataFrame a ser utilizado.
        """
        self.df = df

    def estandarizar_col_num(self):
        """
        Estandariza las columnas numéricas del DataFrame.
        """
        columnas_numericas = self.df.select_dtypes(include=['float64']).columns

        self.df[columnas_numericas] = (self.df[columnas_numericas] - self.df[columnas_numericas].mean()) / self.df[columnas_numericas].std()
        return self.df

    def convertir_a_dummies(self, columnas):
        """
        Convierte las columnas especificadas a variables dummy.

        :param columnas: Lista de nombres de columnas a convertir.
        """
        self.df = pd.get_dummies(self.df, columns=columnas, prefix=columnas)

        return self.df

    def eliminar_columna(self, columna):
        """
        Elimina la columnas del DataFrame

        :param columna: Nombre de la columna a eliminar.
        """
        self.df.drop(columna, axis=1, inplace=True)

        return self.df
    

# Clase para el modelo de clasificación
class ModelClassifier(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.logistic_model = self._build_model()

    def _build_model(self):
        logistic_model = LogisticRegression(random_state=10)
        return logistic_model

    def fit(self, X, y):
        self.logistic_model.fit(X, y)
        return self

    def predict(self, X):
        y_pred = self.logistic_model.predict(X)
        return y_pred


# Clase para el modelo de regresión
class ModelRegressor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.logistic_model = self._build_model()

    def _build_model(self):
        logistic_model = LinearRegression()
        return logistic_model

    def fit(self, X, y):
        self.logistic_model.fit(X, y)
        return self

    def predict(self, X):
        y_pred = self.logistic_model.predict(X)
        return y_pred